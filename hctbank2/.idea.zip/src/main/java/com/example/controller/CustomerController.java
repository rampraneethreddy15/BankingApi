package com.example.controller;

import com.example.model.AccTransaction;
import com.example.model.CustDetails;
import com.example.model.CustomerDetailedAddress;
import com.example.model.NewTransaction;
import com.example.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("hct")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @GetMapping("customers")
    public List<CustDetails> getCustomers(){
        return customerService.getCustomers();
    }

    @GetMapping("customers/{id}")
    public Optional<CustDetails> getCustomerById(@PathVariable long id){
        return customerService.getCustomerById(id);
    }
    @GetMapping("balances")
    public double getBalance(@RequestParam long cust_id,@RequestParam long acc_id){
        if( cust_id == 0 && acc_id ==0){
            System.out.println("wrong");
        }
        else if(cust_id !=0 && acc_id==0){
            return customerService.getBalanceByCustId(cust_id);
        }
        else if(cust_id==0 && acc_id!=0){
            return customerService.getBalanceByAccId(acc_id);
        }
        else{
            return customerService.getBalanceByAccId(acc_id);
        }
        return 0;

    }

    @PostMapping("customers")
    public String addCustomer(@RequestBody CustomerDetailedAddress cdo){

        return customerService.addCustomer(cdo);
    }

    @PostMapping("transactions")
    public String createTransaction(@RequestBody NewTransaction newTransaction){
        String type=newTransaction.getType();
        if(type.equals("credit"))
        {
            System.out.println("calling function");
            return customerService.createTransactionCredit(newTransaction);
        }
        else
            return "error";
    }
    @GetMapping("transactions")
    public List<AccTransaction> getTransactions(@RequestParam long acc_id, @RequestParam long ref_id){
        if( acc_id == 0 && ref_id == 0 ){
            return Li
        }
        else if(acc_id!=0 && ref_id==0){
            System.out.println("using accid");
            return customerService.getTransactionByAccId(acc_id);
        }
        else if (acc_id==0 && ref_id!=0) {

            return customerService.getTransactionByRefId(ref_id);
        }

    }


}

package com.example.service;

import com.example.controller.GenerateRandom;
import com.example.model.*;
import com.example.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    CustomerRepo customerRepo;
    @Autowired
    CustomerAddressRepo customerAddressRepo;
    @Autowired
    AccBalanceRepo accBalanceRepo;
    @Autowired
    CusAccMapRepo cusAccMapRepo;
    @Autowired
    TransactionRepo transactionRepo;
    public List<CustDetails> getCustomers() {
          return customerRepo.findAll();
    }

    public String addCustomer(CustomerDetailedAddress cdo) {
        GenerateRandom gr=new GenerateRandom();
        CustDetails cd=new CustDetails();
        long cid= gr.getRandom();
        cd.setCust_id(cid);
        cd.setName(cdo.getName());
        cd.setPhone(cdo.getPhone());
        cd.setEmail(cdo.getEmail());
        Timestamp currentTimestamp = new Timestamp(new Date().getTime());
        cd.setCreated(currentTimestamp);
        cd.setUpdated(currentTimestamp);

        CustAddress ca=new CustAddress();
        long aid= gr.getRandom();
        ca.setAddress_id(aid);
        ca.setCity(cdo.getCity());
        ca.setPin(cdo.getPin());
        ca.setCountry(cdo.getCountry());
        ca.setAddresslane(cdo.getAddresslane());
        ca.setLastupdate(currentTimestamp);

        cd.setAddress_id(aid);

        customerAddressRepo.save(ca);
        customerRepo.save(cd);


        AccBalance ab=new AccBalance();
        long acc_id=gr.getRandom();
        ab.setAcc_id(acc_id);
        ab.setBalance(500.00);
        accBalanceRepo.save(ab);

        CusAccMap cam=new CusAccMap();
        cam.setAcc_id(acc_id);
        cam.setCust_id(cid);
        cusAccMapRepo.save(cam);
        return "success";
    }

    public Optional<CustDetails> getCustomerById(long id) {
        return customerRepo.findById((int) id);
    }

    public double getBalanceByCustId(long id) {
        CusAccMap cap=cusAccMapRepo.findByCustId(id);
        long acc_id=cap.getAcc_id();
        Optional<AccBalance> ab=accBalanceRepo.findById(acc_id);
        return ab.get().getBalance();
    }

    public double getBalanceByAccId(long acc_id) {
        Optional<AccBalance> ab=accBalanceRepo.findById(acc_id);
        return ab.get().getBalance();
    }

    public String createTransactionCredit(NewTransaction newTransaction) {
        System.out.println("in creating transaction function");
        GenerateRandom gr = new GenerateRandom();
        Timestamp currentTimestamp = new Timestamp(new Date().getTime());
        long acc_id = newTransaction.getAcc_id();
        long to_acc_id = newTransaction.getTo_acc_id();
        String type = newTransaction.getType();
        double amount = newTransaction.getAmount();

        long tid1 = gr.getRandom();
        long tid2 = gr.getRandom();
        long rid = gr.getRandom();
        AccTransaction at1 = new AccTransaction();
        AccTransaction at2 = new AccTransaction();
        at1.setTrans_id(tid1);
        at1.setTrans_refid(rid);
        at1.setAcc_id(acc_id);
        at1.setCredit(0);
        at1.setDebit(amount);
        at1.setLastupdated(currentTimestamp);

        at2.setTrans_id(tid2);
        at2.setTrans_refid(rid);
        at2.setDebit(0);
        at2.setAcc_id(to_acc_id);
        at2.setCredit(amount);
        at2.setLastupdated(currentTimestamp);

        Optional<AccBalance> senderOptional = accBalanceRepo.findById(acc_id);
        if (senderOptional.isPresent()) {
            AccBalance sender = senderOptional.get();
            double senderBalance = sender.getBalance();
            if (senderBalance >= amount) {
                sender.setBalance(senderBalance - amount);
                at1.setAvlbalance(sender.getBalance());
                accBalanceRepo.save(sender);
            } else {
                return "Insufficient balance in sender's account";
            }
        } else {
            return "Sender account not found";
        }

        Optional<AccBalance> receiverOptional = accBalanceRepo.findById(to_acc_id);
        if (receiverOptional.isPresent()) {
            AccBalance receiver = receiverOptional.get();
            double receiverBalance = receiver.getBalance();
            receiver.setBalance(receiverBalance + amount);
            at2.setAvlbalance(receiver.getBalance());
            accBalanceRepo.save(receiver);
        } else {
            return "Receiver account not found";
        }

        transactionRepo.save(at1);
        transactionRepo.save(at2);

        return "Success";
    }


    public List<AccTransaction> getTransactionByAccId(long accid) {
        return transactionRepo.findByAccId(accid);
    }

    public List<AccTransaction> getTransactionByRefId(long refId) {
        return  transactionRepo.findByRefId(refId);
    }
}

package com.example.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;

@Entity
@Data
@Table(name = "custdetails")
public class CustDetails {
    @Id
    private long cust_id;
    private String name;
    private long phone;
    private long address_id;
    private String email;

    private Timestamp Created;
    private Timestamp Updated;

}

package com.example.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Data
@Table(name = "acctransaction")
public class AccTransaction {
    @Id
    private long trans_id;
    private long trans_refid;
    private long acc_id;
    private  double credit;
    private  double debit;
    private  double avlbalance;
    private Timestamp lastupdated;

}

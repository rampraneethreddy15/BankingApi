package com.example.model;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Data
@Table(name="custaddress")
public class CustAddress {
    @Id
    private long address_id;
    private String country;
    private String city;
    private String addresslane;
    private long pin;
    private Timestamp lastupdate;
}
